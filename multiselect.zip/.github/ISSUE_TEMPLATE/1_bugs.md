---
name: "Bug report"
about: "If you've found a bug."
---

<!--
PLEASE READ: HELP US SO WE CAN HELP YOU, BY FILLING OUT THIS TEMPLATE
Issues that do not include enough information might not be picked up and closed.
-->

### Version

* Vue version: <!-- 2 or 3 -->

### Description

<!-- Describe the issue -->

### Demo

Please use our [JSFiddle template](https://jsfiddle.net/29oyhqL5/) to reproduce the bug. Issues without working reproduction might be ignored.