---
name: "Other"
about: "Open an issue about anything else than a bug."
---