export default function normalize (str) {
  return String(str).toLowerCase().trim()
}